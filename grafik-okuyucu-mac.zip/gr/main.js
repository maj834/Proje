const {app,BrowserWindow,Tray,screen,desktopCapturer,ipcMain,globalShortcut,nativeImage}=require('electron');
const fs=require('fs'),path=require('path');
let tray,pop,ov,timer=null,busy=false,ovTimer;
const F=()=>path.join(app.getPath('userData'),'cfg.json');
const cfg=()=>{try{return JSON.parse(fs.readFileSync(F()))}catch(e){return{}}};
const save=o=>fs.writeFileSync(F(),JSON.stringify({...cfg(),...o}));
const SYS='Sen deneyimli bir teknik analiz uzmanisin. Ekran goruntusunde herhangi bir programdaki (TradingView, broker, Matriks, tarayici vb.) fiyat grafigini bul ve oku. Sadece JSON dondur, baska hicbir sey yazma: {"chart_found":bool,"symbol":str|null,"timeframe":str|null,"bias":"yukselis"|"dusus"|"notr","confidence":0-100,"trend":str,"resistances":[{"price":num|null,"y":0-1}],"supports":[{"price":num|null,"y":0-1}],"breakout":str|null,"patterns":[str],"comment":"Turkce, kisa, net, gerekceli yorum"}. y degeri cizginin ekran goruntusunun ustunden itibaren dikey konumudur (0 ust, 1 alt). Fiyat eksenini oku, tahmin ettiysen price null birak. En fazla 3 destek ve 3 direnc ver.';
function mk(){
  const pre=path.join(__dirname,'preload.js');
  pop=new BrowserWindow({width:360,height:540,show:false,frame:false,resizable:false,skipTaskbar:true,alwaysOnTop:true,transparent:true,vibrancy:'under-window',visualEffectState:'active',webPreferences:{preload:pre}});
  pop.setContentProtection(true);pop.loadFile('popup.html');
  pop.on('blur',()=>pop.hide());
  const b=screen.getPrimaryDisplay().bounds;
  ov=new BrowserWindow({x:b.x,y:b.y,width:b.width,height:b.height,transparent:true,frame:false,focusable:false,hasShadow:false,skipTaskbar:true,show:false,webPreferences:{preload:pre}});
  ov.setAlwaysOnTop(true,'screen-saver');ov.setIgnoreMouseEvents(true);ov.setContentProtection(true);ov.loadFile('overlay.html');
}
function toggle(){
  if(pop.isVisible())return pop.hide();
  const t=tray.getBounds();pop.setPosition(Math.round(t.x+t.width/2-180),t.y+t.height+4);pop.show();
}
async function analyze(){
  if(busy)return;const k=cfg().key;
  if(!k){pop.webContents.send('err','Once API anahtarini gir (asagida Ayarlar).');return pop.show()}
  busy=true;pop.webContents.send('busy',1);
  try{
    const d=screen.getPrimaryDisplay(),w=1600,h=Math.round(w*d.size.height/d.size.width);
    const [src]=await desktopCapturer.getSources({types:['screen'],thumbnailSize:{width:w,height:h}});
    const img=src.thumbnail.toJPEG(80).toString('base64');
    const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':k,'anthropic-version':'2023-06-01'},
      body:JSON.stringify({model:cfg().model||'claude-sonnet-5-5',max_tokens:1200,system:SYS,messages:[{role:'user',content:[{type:'image',source:{type:'base64',media_type:'image/jpeg',data:img}},{type:'text',text:'Ekrandaki grafigi analiz et.'}]}]})});
    const j=await r.json();if(j.error)throw new Error(j.error.message);
    const t=j.content.map(c=>c.text||'').join('');
    const a=JSON.parse(t.slice(t.indexOf('{'),t.lastIndexOf('}')+1));
    pop.webContents.send('result',a);
    if(a.chart_found){ov.webContents.send('draw',a);ov.showInactive();clearTimeout(ovTimer);ovTimer=setTimeout(()=>ov.hide(),cfg().live?40000:25000)}
  }catch(e){pop.webContents.send('err',String(e.message||e))}
  busy=false;
}
app.whenReady().then(()=>{
  app.dock&&app.dock.hide();mk();
  tray=new Tray(nativeImage.createEmpty());tray.setTitle('◢ Grafik');tray.on('click',toggle);
  globalShortcut.register('CommandOrControl+Shift+A',analyze);
  ipcMain.handle('analyze',analyze);
  ipcMain.handle('key',(e,k)=>save({key:k}));
  ipcMain.handle('cfg',()=>({hasKey:!!cfg().key,live:!!cfg().live}));
  ipcMain.handle('live',(e,on)=>{save({live:on});clearInterval(timer);if(on)timer=setInterval(analyze,20000)});
  if(cfg().live)timer=setInterval(analyze,20000);
});
app.on('window-all-closed',e=>e.preventDefault());
