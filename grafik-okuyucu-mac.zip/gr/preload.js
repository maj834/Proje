const {contextBridge,ipcRenderer:i}=require('electron');
contextBridge.exposeInMainWorld('api',{analyze:()=>i.invoke('analyze'),key:k=>i.invoke('key',k),live:o=>i.invoke('live',o),cfg:()=>i.invoke('cfg'),on:(c,f)=>i.on(c,(_,d)=>f(d))});
